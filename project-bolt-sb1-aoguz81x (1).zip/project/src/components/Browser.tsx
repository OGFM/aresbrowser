import React from 'react';
import BrowserContent from './BrowserContent';

const Browser: React.FC = () => {
  return (
    <div className="flex flex-col w-full h-screen bg-slate-50 overflow-hidden">
      <div className="flex-1 overflow-hidden">
        <BrowserContent
          url=""
          isLoading={false}
        />
      </div>
    </div>
  );
};

export default Browser;
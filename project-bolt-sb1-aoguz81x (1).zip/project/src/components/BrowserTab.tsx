import React from 'react';
import { X } from 'lucide-react';

interface BrowserTabProps {
  title: string;
  favicon?: string;
  isActive: boolean;
  onActivate: () => void;
  onClose: () => void;
}

const BrowserTab: React.FC<BrowserTabProps> = ({
  title,
  favicon,
  isActive,
  onActivate,
  onClose
}) => {
  return (
    <div 
      className={`flex items-center max-w-[200px] min-w-[100px] h-9 px-3 py-1 rounded-t-lg cursor-pointer transition-colors relative ${
        isActive 
          ? 'bg-white text-slate-800' 
          : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
      }`}
      onClick={onActivate}
    >
      {favicon && (
        <img 
          src={favicon} 
          alt="" 
          className="w-4 h-4 mr-2"
        />
      )}
      <span className="truncate text-sm font-medium flex-1">
        {title || 'New Tab'}
      </span>
      <button 
        className="ml-2 p-0.5 rounded-full text-slate-500 hover:bg-slate-300 hover:text-slate-700 transition-colors"
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
      >
        <X size={14} />
      </button>
    </div>
  );
};

export default BrowserTab;
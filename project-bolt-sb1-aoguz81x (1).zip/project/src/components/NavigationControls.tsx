import React from 'react';
import { ArrowLeft, ArrowRight, RefreshCw, Home } from 'lucide-react';

interface NavigationControlsProps {
  canGoBack: boolean;
  canGoForward: boolean;
  onBack: () => void;
  onForward: () => void;
  onRefresh: () => void;
  onHome: () => void;
}

const NavigationControls: React.FC<NavigationControlsProps> = ({
  canGoBack,
  canGoForward,
  onBack,
  onForward,
  onRefresh,
  onHome
}) => {
  return (
    <div className="flex items-center space-x-1">
      <button 
        className={`p-2 rounded-full ${
          canGoBack 
            ? 'text-slate-600 hover:bg-slate-200' 
            : 'text-slate-300 cursor-not-allowed'
        }`}
        onClick={onBack}
        disabled={!canGoBack}
      >
        <ArrowLeft size={18} />
      </button>
      
      <button 
        className={`p-2 rounded-full ${
          canGoForward 
            ? 'text-slate-600 hover:bg-slate-200' 
            : 'text-slate-300 cursor-not-allowed'
        }`}
        onClick={onForward}
        disabled={!canGoForward}
      >
        <ArrowRight size={18} />
      </button>
      
      <button 
        className="p-2 rounded-full text-slate-600 hover:bg-slate-200"
        onClick={onRefresh}
      >
        <RefreshCw size={18} />
      </button>
      
      <button 
        className="p-2 rounded-full text-slate-600 hover:bg-slate-200"
        onClick={onHome}
      >
        <Home size={18} />
      </button>
    </div>
  );
};

export default NavigationControls;
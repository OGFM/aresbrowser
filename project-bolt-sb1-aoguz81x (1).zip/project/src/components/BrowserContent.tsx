import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface BrowserContentProps {
  url: string;
  isLoading: boolean;
}

interface SearchResult {
  title: string;
  link: string;
  snippet: string;
}

const BrowserContent: React.FC<BrowserContentProps> = ({ url, isLoading }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [startIndex, setStartIndex] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  
  const getDisplayUrl = () => {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname + urlObj.pathname;
    } catch (e) {
      return url;
    }
  };

  const fetchSearchResults = async (query: string, start: number) => {
    try {
      const response = await fetch(
        `https://www.googleapis.com/customsearch/v1?key=AIzaSyB7JCASQ0zh1Khr7GQ3dfP2v5o-EkZg6lE&cx=12d9c148e8cb64388&q=${encodeURIComponent(query)}&start=${start}`
      );
      
      const data = await response.json();
      
      if (data.items) {
        const newResults = data.items.map((item: any) => ({
          title: item.title,
          link: item.link,
          snippet: item.snippet
        }));
        
        if (start === 1) {
          setSearchResults(newResults);
        } else {
          setSearchResults(prev => [...prev, ...newResults]);
        }
        
        setHasMore(data.queries?.nextPage !== undefined);
      }
    } catch (error) {
      console.error('Search error:', error);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setStartIndex(1);
    await fetchSearchResults(searchQuery, 1);
    setIsSearching(false);
  };

  const loadMore = async () => {
    if (!isSearching && hasMore) {
      setIsSearching(true);
      const nextStartIndex = startIndex + 10;
      setStartIndex(nextStartIndex);
      await fetchSearchResults(searchQuery, nextStartIndex);
      setIsSearching(false);
    }
  };

  const handleResultClick = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const bottom = e.currentTarget.scrollHeight - e.currentTarget.scrollTop === e.currentTarget.clientHeight;
    if (bottom && hasMore && !isSearching) {
      loadMore();
    }
  };
  
  return (
    <div className="flex flex-col items-center w-full h-full bg-white overflow-hidden rounded-b-lg border border-slate-200 border-t-0">
      {isLoading ? (
        <div className="flex flex-col items-center justify-center h-full">
          <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-500 rounded-full animate-spin mb-4"></div>
          <p className="text-slate-500">Loading {getDisplayUrl()}...</p>
        </div>
      ) : url ? (
        <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
          <h2 className="text-xl font-semibold text-slate-700 mb-2">Demo Browser Simulation</h2>
          <p className="text-slate-600 mb-4">
            This is a simulated browser interface. In a real implementation, this area would display the actual webpage content.
          </p>
          <p className="text-sm text-slate-500">
            Current URL: <span className="font-mono">{url}</span>
          </p>
        </div>
      ) : (
        <div className="flex flex-col items-center w-full h-full">
          <div 
            className={`flex flex-col items-center justify-center w-full transition-all duration-500 ${
              searchResults.length > 0 ? 'h-48' : 'h-full'
            }`}
          >
            <div className={`flex flex-col items-center space-y-8 transition-all duration-500 ${
              searchResults.length > 0 ? '-translate-y-4' : 'translate-y-0'
            }`}>
              <h1 className="text-6xl font-bold tracking-tighter text-slate-800">ares</h1>
              <div className="w-[600px] max-w-full px-4">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    placeholder="Search anything..."
                    className="w-full h-12 pl-4 pr-12 bg-slate-100 rounded-full border-2 border-transparent focus:border-slate-400 focus:outline-none text-slate-800 placeholder-slate-400 transition-colors"
                  />
                  <button 
                    onClick={handleSearch}
                    className="absolute right-2 top-2 p-2 bg-slate-400 text-white rounded-full hover:bg-slate-500 transition-colors"
                  >
                    <Search size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          {searchResults.length > 0 && (
            <div 
              className="flex-1 w-full max-w-4xl px-4 overflow-y-auto"
              onScroll={handleScroll}
            >
              <div className="space-y-6 pb-8">
                {searchResults.map((result, index) => (
                  <div 
                    key={index} 
                    className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => handleResultClick(result.link)}
                  >
                    <div className="text-lg font-medium text-blue-600 hover:underline">{result.title}</div>
                    <p className="text-sm text-slate-600 mt-1">{result.snippet}</p>
                    <p className="text-xs text-slate-400 mt-1">{result.link}</p>
                  </div>
                ))}
                
                {isSearching && (
                  <div className="flex justify-center py-4">
                    <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-500 rounded-full animate-spin"></div>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {!searchResults.length && !isSearching && (
            <div className="absolute bottom-8 text-sm text-slate-400">
              By Max Volkov
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BrowserContent;
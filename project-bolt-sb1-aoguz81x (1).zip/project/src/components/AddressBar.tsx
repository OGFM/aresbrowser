import React, { useState } from 'react';
import { Search, ArrowRight, Star, StarOff } from 'lucide-react';

interface AddressBarProps {
  currentUrl: string;
  isBookmarked: boolean;
  onNavigate: (url: string) => void;
  onBookmarkToggle: () => void;
}

const AddressBar: React.FC<AddressBarProps> = ({
  currentUrl,
  isBookmarked,
  onNavigate,
  onBookmarkToggle
}) => {
  const [inputValue, setInputValue] = useState(currentUrl);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let url = inputValue.trim();
    
    if (!/^https?:\/\//i.test(url)) {
      if (/\w+\.\w{2,}/.test(url)) {
        url = `https://${url}`;
      } else {
        url = `https://www.google.com/search?q=${encodeURIComponent(url)}`;
      }
    }
    
    onNavigate(url);
  };

  return (
    <div className="flex items-center w-full h-10 bg-slate-100 rounded-lg border border-slate-200 overflow-hidden">
      <div className="px-3 text-slate-400">
        <Search size={16} />
      </div>
      
      <form onSubmit={handleSubmit} className="flex-1 flex items-center">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="w-full h-full px-3 bg-transparent border-none outline-none text-sm text-slate-800 placeholder-slate-400"
          placeholder="Search anything..."
        />
        <button
          type="submit"
          className="p-2 text-slate-500 hover:text-slate-700"
        >
          <ArrowRight size={16} />
        </button>
      </form>
      
      <button
        onClick={onBookmarkToggle}
        className="px-3 text-slate-400 hover:text-purple-500 transition-colors"
      >
        {isBookmarked ? <Star size={16} className="fill-yellow-400 text-yellow-400" /> : <StarOff size={16} />}
      </button>
    </div>
  );
};

export default AddressBar;
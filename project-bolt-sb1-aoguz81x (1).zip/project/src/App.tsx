import React from 'react';
import Browser from './components/Browser';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-1 sm:p-2 md:p-4">
      <div className="bg-white rounded-lg shadow-xl overflow-hidden w-full h-[calc(100vh-32px)]">
        <Browser />
      </div>
    </div>
  );
}

export default App;
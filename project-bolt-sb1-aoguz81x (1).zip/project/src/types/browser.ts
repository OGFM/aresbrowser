export interface Tab {
  id: string;
  title: string;
  url: string;
  favicon?: string;
  history: string[];
  historyIndex: number;
  isLoading: boolean;
}

export interface Bookmark {
  id: string;
  title: string;
  url: string;
  favicon?: string;
  dateAdded: Date;
}

export interface BrowserHistory {
  url: string;
  title: string;
  visitDate: Date;
  favicon?: string;
}
import { useState, useCallback } from 'react';
import { Tab } from '../types/browser';

export const useBrowserTabs = () => {
  // Initialize with one empty tab
  const [tabs, setTabs] = useState<Tab[]>([{
    id: '1',
    title: 'New Tab',
    url: '',
    history: [],
    historyIndex: -1,
    isLoading: false
  }]);
  
  const [activeTabId, setActiveTabId] = useState<string>('1');
  
  const getActiveTab = useCallback(() => {
    return tabs.find(tab => tab.id === activeTabId) || tabs[0];
  }, [tabs, activeTabId]);

  const addTab = useCallback(() => {
    const newTabId = Date.now().toString();
    const newTab: Tab = {
      id: newTabId,
      title: 'New Tab',
      url: '',
      history: [],
      historyIndex: -1,
      isLoading: false
    };
    
    setTabs(prevTabs => [...prevTabs, newTab]);
    setActiveTabId(newTabId);
    
    return newTabId;
  }, []);

  const closeTab = useCallback((tabId: string) => {
    setTabs(prevTabs => {
      // Don't close if it's the only tab
      if (prevTabs.length <= 1) return prevTabs;
      
      const tabIndex = prevTabs.findIndex(tab => tab.id === tabId);
      const newTabs = prevTabs.filter(tab => tab.id !== tabId);
      
      // If we're closing the active tab, activate the next available tab
      if (tabId === activeTabId) {
        // If we're closing the last tab, activate the previous one
        const newActiveIndex = tabIndex === prevTabs.length - 1 ? tabIndex - 1 : tabIndex;
        setActiveTabId(newTabs[newActiveIndex].id);
      }
      
      return newTabs;
    });
  }, [activeTabId]);

  const activateTab = useCallback((tabId: string) => {
    setActiveTabId(tabId);
  }, []);

  const updateTabUrl = useCallback((tabId: string, url: string) => {
    setTabs(prevTabs => 
      prevTabs.map(tab => {
        if (tab.id !== tabId) return tab;
        
        // Add current URL to history if it exists and is different
        const updatedHistory = [...tab.history.slice(0, tab.historyIndex + 1)];
        if (tab.url && tab.url !== url) {
          updatedHistory.push(tab.url);
        }
        
        return {
          ...tab,
          url,
          title: url ? new URL(url).hostname : 'New Tab',
          isLoading: true,
          history: updatedHistory,
          historyIndex: updatedHistory.length - 1
        };
      })
    );
    
    // Simulate page loading
    setTimeout(() => {
      setTabs(prevTabs => 
        prevTabs.map(tab => {
          if (tab.id !== tabId) return tab;
          return { ...tab, isLoading: false };
        })
      );
    }, 1500);
  }, []);

  const navigateTabHistory = useCallback((tabId: string, direction: 'back' | 'forward') => {
    setTabs(prevTabs => 
      prevTabs.map(tab => {
        if (tab.id !== tabId) return tab;
        
        const newIndex = direction === 'back' 
          ? Math.max(0, tab.historyIndex - 1)
          : Math.min(tab.history.length - 1, tab.historyIndex + 1);
        
        if (newIndex === tab.historyIndex) return tab;
        
        return {
          ...tab,
          historyIndex: newIndex,
          url: tab.history[newIndex] || '',
          isLoading: true
        };
      })
    );
    
    // Simulate page loading
    setTimeout(() => {
      setTabs(prevTabs => 
        prevTabs.map(tab => {
          if (tab.id !== tabId) return tab;
          return { ...tab, isLoading: false };
        })
      );
    }, 1000);
  }, []);

  const refreshTab = useCallback((tabId: string) => {
    setTabs(prevTabs => 
      prevTabs.map(tab => {
        if (tab.id !== tabId) return tab;
        return { ...tab, isLoading: true };
      })
    );
    
    // Simulate page loading
    setTimeout(() => {
      setTabs(prevTabs => 
        prevTabs.map(tab => {
          if (tab.id !== tabId) return tab;
          return { ...tab, isLoading: false };
        })
      );
    }, 1000);
  }, []);

  return {
    tabs,
    activeTabId,
    getActiveTab,
    addTab,
    closeTab,
    activateTab,
    updateTabUrl,
    navigateTabHistory,
    refreshTab
  };
};

export default useBrowserTabs;
import { useState, useCallback } from 'react';
import { Bookmark } from '../types/browser';

export const useBookmarks = () => {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);

  const addBookmark = useCallback((title: string, url: string, favicon?: string) => {
    const newBookmark: Bookmark = {
      id: Date.now().toString(),
      title,
      url,
      favicon,
      dateAdded: new Date()
    };
    
    setBookmarks(prevBookmarks => [...prevBookmarks, newBookmark]);
    return newBookmark;
  }, []);

  const removeBookmark = useCallback((id: string) => {
    setBookmarks(prevBookmarks => prevBookmarks.filter(bookmark => bookmark.id !== id));
  }, []);

  const isUrlBookmarked = useCallback((url: string) => {
    return bookmarks.some(bookmark => bookmark.url === url);
  }, [bookmarks]);

  const toggleBookmark = useCallback((title: string, url: string, favicon?: string) => {
    const existingBookmark = bookmarks.find(bookmark => bookmark.url === url);
    
    if (existingBookmark) {
      removeBookmark(existingBookmark.id);
      return false;
    } else {
      addBookmark(title, url, favicon);
      return true;
    }
  }, [bookmarks, addBookmark, removeBookmark]);

  return {
    bookmarks,
    addBookmark,
    removeBookmark,
    isUrlBookmarked,
    toggleBookmark
  };
};

export default useBookmarks;